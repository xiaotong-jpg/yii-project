let dictionaryCard = null;

document.addEventListener('dblclick', async (event) => {
  const selectedText = window.getSelection().toString().trim();

  if (selectedText) {
    removeCard();

    try {
      const definition = await fetchDefinition(selectedText);
      showCard(definition, event.clientX, event.clientY);
    } catch (error) {
      showCard(error.message, event.clientX, event.clientY);
    }
  }
});

document.addEventListener('mousedown', (event) => {
  if (dictionaryCard && !dictionaryCard.contains(event.target)) {
    removeCard();
  }
});

async function fetchDefinition(word) {
  const apiUrl = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;
  const response = await fetch(apiUrl);

  if (!response.ok) {
    throw new Error('Sorry, no definition found for this word.');
  }

  const data = await response.json();
  const firstDefinition = data[0]?.meanings[0]?.definitions[0]?.definition;

  if (!firstDefinition) {
    throw new Error('Sorry, no definition found for this word.');
  }
  
  return firstDefinition;
}

function showCard(text, x, y) {
  dictionaryCard = document.createElement('div');
  dictionaryCard.className = 'instant-dictionary-card';
  dictionaryCard.textContent = text;

  dictionaryCard.style.top = `${window.scrollY + y + 10}px`;
  dictionaryCard.style.left = `${window.scrollX + x + 10}px`;

  document.body.appendChild(dictionaryCard);
}

function removeCard() {
  if (dictionaryCard) {
    dictionaryCard.remove();
    dictionaryCard = null;
  }
}