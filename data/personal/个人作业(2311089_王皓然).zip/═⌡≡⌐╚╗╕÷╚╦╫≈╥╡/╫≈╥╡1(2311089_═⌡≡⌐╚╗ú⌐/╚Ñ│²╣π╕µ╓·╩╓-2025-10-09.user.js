// ==UserScript==
// @name         去除广告助手
// @namespace    http://tampermonkey.net/
// @version      2025-10-09
// @description  try to take over the world!
// @author       You
// @match        *://www.baidu.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    console.log("hello，去除广告助手已启动！");
    function removeAds() {
        // 添加针对您提供的广告元素的选择器
        const ads = document.querySelectorAll(
            '[class*="ad"], ' +
            '[class*="广告"], ' +
            '[class*="推广"], ' +
            '[class*="tuiguang"], ' +
            '[data-tuiguang]'
        );
        ads.forEach(ad => ad.remove());
        console.log('已清理页面广告');
    }

    // 页面加载完成后执行一次
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', removeAds);
    } else {
        removeAds();
    }
})();