图标文件说明
============

请在此文件夹中放置以下图标文件：
- icon16.png (16x16像素)
- icon48.png (48x48像素)  
- icon128.png (128x128像素)

如果没有图标文件，插件仍然可以正常工作，只是不会显示图标。

您可以使用在线图标生成工具创建图标，例如：
- https://www.favicon-generator.org/
- https://realfavicongenerator.net/

或者使用简单的图片编辑工具创建。

