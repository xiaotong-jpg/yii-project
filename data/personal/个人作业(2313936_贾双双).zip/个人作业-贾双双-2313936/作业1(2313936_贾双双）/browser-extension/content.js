// Content Script - 在网页中运行的脚本

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'showPageInfo') {
        const info = {
            title: document.title,
            url: window.location.href,
            linkCount: document.getElementsByTagName('a').length,
            imageCount: document.getElementsByTagName('img').length,
            textLength: document.body.innerText.length
        };
        sendResponse({ success: true, info: info });
    }
    
    if (request.action === 'copyTitle') {
        sendResponse({ success: true, title: document.title });
    }
    
    if (request.action === 'toggleNightMode') {
        toggleNightMode(request.enabled);
        sendResponse({ success: true });
    }
    
    return true; // 保持消息通道开放
});

// 夜间模式切换函数
function toggleNightMode(enabled) {
    const styleId = 'night-mode-style';
    let styleElement = document.getElementById(styleId);
    
    if (enabled) {
        if (!styleElement) {
            styleElement = document.createElement('style');
            styleElement.id = styleId;
            document.head.appendChild(styleElement);
        }
        styleElement.textContent = `
            body, html {
                background-color: #1a1a1a !important;
                color: #e0e0e0 !important;
                filter: invert(1) hue-rotate(180deg) !important;
            }
            img, video, iframe {
                filter: invert(1) hue-rotate(180deg) !important;
            }
        `;
    } else {
        if (styleElement) {
            styleElement.remove();
        }
    }
}

// 页面加载时检查是否需要应用夜间模式
chrome.storage.local.get(['nightMode'], (result) => {
    if (result.nightMode) {
        toggleNightMode(true);
    }
});

