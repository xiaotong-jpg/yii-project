// 弹出窗口的JavaScript逻辑

// 获取当前活动标签页
async function getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
}

// 功能1: 显示页面信息
document.getElementById('showInfo').addEventListener('click', async () => {
    const tab = await getCurrentTab();
    
    chrome.tabs.sendMessage(tab.id, { action: 'showPageInfo' }, (response) => {
        if (response && response.success) {
            alert('页面信息:\n\n' + 
                  '标题: ' + response.info.title + '\n' +
                  'URL: ' + response.info.url + '\n' +
                  '链接数: ' + response.info.linkCount + '\n' +
                  '图片数: ' + response.info.imageCount + '\n' +
                  '字符数: ' + response.info.textLength);
        } else {
            alert('无法获取页面信息，请刷新页面后重试');
        }
    });
});

// 功能2: 复制页面标题
document.getElementById('copyTitle').addEventListener('click', async () => {
    const tab = await getCurrentTab();
    
    chrome.tabs.sendMessage(tab.id, { action: 'copyTitle' }, (response) => {
        if (response && response.success) {
            // 使用Clipboard API复制
            navigator.clipboard.writeText(response.title).then(() => {
                alert('页面标题已复制到剪贴板！\n\n' + response.title);
            }).catch(() => {
                alert('复制失败，请手动复制:\n\n' + response.title);
            });
        } else {
            alert('无法获取页面标题');
        }
    });
});

// 功能3: 切换夜间模式
document.getElementById('toggleNightMode').addEventListener('click', async () => {
    const tab = await getCurrentTab();
    
    // 获取当前夜间模式状态
    chrome.storage.local.get(['nightMode'], async (result) => {
        const isNightMode = !result.nightMode;
        
        // 保存状态
        chrome.storage.local.set({ nightMode: isNightMode });
        
        // 发送消息给content script
        chrome.tabs.sendMessage(tab.id, { 
            action: 'toggleNightMode', 
            enabled: isNightMode 
        }, (response) => {
            if (response && response.success) {
                updateNightModeStatus(isNightMode);
            }
        });
    });
});

// 更新夜间模式状态显示
function updateNightModeStatus(enabled) {
    const statusEl = document.getElementById('nightModeStatus');
    if (enabled) {
        statusEl.textContent = '开启';
        statusEl.className = 'status on';
    } else {
        statusEl.textContent = '关闭';
        statusEl.className = 'status off';
    }
}

// 页面加载时检查夜间模式状态
chrome.storage.local.get(['nightMode'], (result) => {
    if (result.nightMode) {
        updateNightModeStatus(true);
    }
});

